#include "actuator.h"



void actuators_begin(void)
{
  pinMode(PIN_LED_GREEN ,OUTPUT);
  pinMode(PIN_LED_YELLOW ,OUTPUT);
  pinMode(PIN_LED_RED ,OUTPUT);


  digitalWrite(PIN_LED_RED,HIGH);
  
}