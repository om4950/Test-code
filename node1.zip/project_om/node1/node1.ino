// include required libraries
#include <SPI.h>
#include <Ethernet.h>
#include <PubSubClient.h>
#include <DHT.h>

#include "config.h"
#include "SensorManager.h"
#include "actuator.h"
#include "network.h"
#include "telemetry.h"

static char sharedBuf[200];

static EthernetClient ethClient;
static PubSubClient mqttClient(ethClient);   // ✅ fixed

unsigned long lastTelemetry = 0;

void setup() 
{
  Serial.begin(9600);
  Serial.print("Node1 is booting...");   // ✅ fixed

  // initialize sensor
  sensor_begin();

  // initialize actuators
  actuators_begin();

  telemetry_init(sharedBuf, sizeof(sharedBuf));
  rpc_init(mqttClient,sharedBuf, sizeof(sharedBuf));
  
  mqttClient.setcallback(rpc_mqttCallback);
  // connect board to internet and mqtt
  network_begin(&mqttClient);
  mqttClient.setcallback(rpc_mqttCallback);

  digitalWrite(PIN_LED_RED, LOW);   // ✅ fixed
}

void loop() 
{
  network_maintain();

  SensorData data;   // ✅ fixed
  sensors_read(&data);

  if(network_isConnected())   // ✅ fixed
  {
    unsigned long now = millis();

    if(now - lastTelemetry >= TELEMETRY_INTERVAL)
    {
      lastTelemetry = now;
      telemetry_publishTelemetry(&data, 1);
    }
  }
}