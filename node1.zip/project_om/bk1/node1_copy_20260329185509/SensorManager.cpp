#include "SensorManager.h"
#include "config.h"
#include <DHT.h>

static DHT dht(PIN_DHT , DHT_TYPE);

static float lastTemp;
static float lastHumidity;

void sensor_begin(void)
{
  pinMode(PIN_BUTTON, INPUT_PULLUP);
  dht.begin();
}

// ---------- VIBRATION ----------
static uint16_t readVibration(void)
{
   uint16_t sum = 0;

   for(uint16_t i = 0; i < 4; i++)
   {
     sum += analogRead(PIN_VIBRATION);
     delay(100);
   }

   return sum / 4;
}

// ---------- LM35 ----------
static float readLM35(void)
{
  float t = analogRead(PIN_LM35) * (500.0f / 1023.0f);
  return round(t * 10.0f) * 0.1f;
}

// ---------- MAIN SENSOR FUNCTION ----------
uint8_t sensors_read(SensorData* out)
{
  float t = dht.readTemperature();
  float h = dht.readHumidity();

  if (isnan(t) || isnan(h))
  {
    out->sensorError = 1;
    out->temperature = lastTemp;
    out->humidity = lastHumidity;
  }
  else 
  {
    out->sensorError = 0;
    out->temperature = round(t * 10.0f) * 0.1f;
    out->humidity = round(h * 10.0f) * 0.1f;

    lastTemp = out->temperature;
    lastHumidity = out->humidity;
  }

  out->lm35Temp = readLM35();
  out->vibration = readVibration();
  out->machineStatus = (digitalRead(PIN_BUTTON) == LOW) ? 1 : 0;

  return !out->sensorError;
}