#include <DHT.h>

#define DHTPIN 2  
#define DHTTYPE DHT22 
// datpin 2 , type DHT22

DHT dht(DHTPIN, DHTTYPE); // create object of type DHT


void setup() 
{ 
   dht.begin(); 
   Serial.begin(9600);
   Serial.println("test DHT22 sensor :- "); 
 }

unsigned long now;
unsigned long prev;
float h ;
float t ;
void loop() 
{
  now = millis();// time elapsed in ms

  if( (now - prev) > 2000 )
  {  
    prev = now;
     h = dht.readHumidity();
     t = dht.readTemperature();

     
      
    //handle sensor failure
    if (isnan(h) || isnan(t)) 
       {
       Serial.println("Read failed!");
       return;  // skip loop
       }

       Serial.print("Temperature is ");
       Serial.print(t);
       Serial.println("celsius");

      Serial.print("Humidity is ");
      Serial.print(h);
      Serial.println("percentage");

  }
    // print 
    

   

}
   
