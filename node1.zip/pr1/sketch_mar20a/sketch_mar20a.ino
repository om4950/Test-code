#define LED_BUILTIN 2

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
}

void loop() {
  digitalWrite(LED_BUILTIN, HIGH); // ON
  delay(1000);                     // 1 second
  digitalWrite(LED_BUILTIN, LOW);  // OFF
  delay(1000);                     // 1 second
}
